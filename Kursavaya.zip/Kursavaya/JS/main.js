const osList = [
    "Windows 8",
    "Windows Vista/7",
    "Windows XP",
    "Linux",
    "Mac OS X",
    "Android",
    "Blackberry",
    "iPhone",
    "Symbian OS",
    "Windows Mobile",
    "Windows Phone",
    "Amazon Kindle"
];


function recordOS(osName) {
    let osId = osList.indexOf(osName);
    fetch(`http://localhost:5555/api/usage/add?system=${osId}`);
}

  function toggleLeftMenu() {
    var menu = document.getElementById("menu");
    var overlay = document.getElementById("overlay");
    menu.classList.toggle("active");
    overlay.classList.toggle("active");
}
document.querySelector('.close_button').addEventListener('click', function() {
    var leftPanel = document.querySelector('.left_panel');
    var overlay = document.querySelector('.overlay');
    leftPanel.style.display = 'none';
    overlay.classList.remove('active'); // Удаляем класс для скрытия overlay
});

document.querySelector('.hamburger').addEventListener('click', function() {
    var leftPanel = document.querySelector('.left_panel');
    var overlay = document.querySelector('.overlay');
    leftPanel.style.display = leftPanel.style.display === 'none' ? 'flex' : 'none';
    overlay.classList.toggle('active'); // Переключаем класс для показа/скрытия overlay
});

document.addEventListener("DOMContentLoaded", function() {
    var leftPanel = document.querySelector('.left_panel');
    var overlay = document.querySelector('.overlay');

    // Скрыть левую панель и оверлей при загрузке страницы
    leftPanel.style.display = 'none';
    overlay.style.display = 'none';
});