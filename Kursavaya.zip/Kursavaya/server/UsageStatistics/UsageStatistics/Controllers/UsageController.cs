using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using UsageStatistics.Models;

namespace UsageStatistics.Controllers;

[ApiController]
[Route("api/[controller]")]
public class UsageController : ControllerBase
{
    private uint[] _data = new uint[Enum.GetNames(typeof(SiteOperationSystem)).Length];
    private const string FileName = "data.json";
    private readonly object _fileLock = new();

    [HttpGet("add")]
    public IActionResult Add(SiteOperationSystem system)
    {
        lock (_fileLock)
        {
            if (!System.IO.File.Exists(FileName))
            {
                System.IO.File.Create(FileName);
            }
            else
            {
                var deserializedJson = System.IO.File.ReadAllText(FileName);
                try
                {
                    _data = JsonSerializer.Deserialize<uint[]>(deserializedJson)!;
                }
                catch
                {
                    _data = new uint[Enum.GetNames(typeof(SiteOperationSystem)).Length];
                }
            }

            _data[(int)system]++;


            var json = JsonSerializer.Serialize(_data);
            System.IO.File.WriteAllText(FileName, json);
        }

        return Ok();
    }
    
    [HttpGet("getstatistics")]
    public IActionResult Get()
    {
        lock (_fileLock)
        {
            if (!System.IO.File.Exists(FileName))
            {
                System.IO.File.Create(FileName);
            }
            else
            {
                var deserializedJson = System.IO.File.ReadAllText(FileName);
                try
                {
                    _data = JsonSerializer.Deserialize<uint[]>(deserializedJson)!;
                }
                catch
                {
                    _data = new uint[Enum.GetNames(typeof(SiteOperationSystem)).Length];
                }
            }


            var json = JsonSerializer.Serialize(_data);
            return Ok(json);
        }
    }
}