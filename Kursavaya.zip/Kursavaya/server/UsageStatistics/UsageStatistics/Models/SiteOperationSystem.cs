namespace UsageStatistics.Models;

public enum SiteOperationSystem
{
    Windows8,
    WindowsVista7,
    WindowsXP,
    Linux,
    MacOSX,
    Android,
    Blackberry,
    iPhone,
    SymbianOS,
    WindowsMobile,
    WindowsPhone,
    AmazonKindle
}